import React from 'react';
import module from './Header.module.scss'


function Header(props) {
    return (
        <header className={module.header}>
            <div className={module.header_content}>
                <h3>
                    w
                </h3>

                <h3>
                    e
                </h3>

                <h3>
                    a
                </h3>

                <h3>
                    t
                </h3>
                
                <h3>
                    h
                </h3>

                <h3>
                    e
                </h3>

                <h3>
                    r
                </h3>
            </div>
        </header>
    );
}

export default Header;